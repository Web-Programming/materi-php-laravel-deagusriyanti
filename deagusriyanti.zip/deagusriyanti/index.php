<?php
    echo "Selamat Datang di PHP";

    //INI KOMENTAR SINGLE LINE
    /*
    INI KOMENTAR 
    MULTI LINE
    */

    
?>














